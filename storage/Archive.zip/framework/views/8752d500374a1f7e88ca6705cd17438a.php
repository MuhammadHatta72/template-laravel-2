<div class="footer-left">
    Copyright &copy; 2024
    <div class="bullet"></div>
    Developed By Nila Ayu Setyaningrum
</div>

<?php /**PATH /var/www/html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>