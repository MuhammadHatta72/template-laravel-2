<?php $__env->startSection("title", "Tambah Penerima Bantuan"); ?>

<?php $__env->startSection("styles"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/modules/select2/dist/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/modules/bootstrap-daterangepicker/daterangepicker.css")); ?>">
    <style>
        .select2-container {
            display: block;
            /* atau display: inline-block; */
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Tambah Penerima Bantuan</h1>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session("success")); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Penerima Bantuan</h4>
                        </div>
                        <div class="card-body">
                            <form method="post" id="form-id" action="<?php echo e(route("aid-recipients-criteria.store")); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("post"); ?>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="aid_recipient_id" class="form-label">Masyarakat<span
                                                class="text-danger">*</span></label>
                                        <select class="form-control select2 <?php $__errorArgs = ["aid_recipient_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="aid_recipient_id" name="aid_recipient_id" required>
                                            <option value="">Pilih Masyarakat</option>
                                            <?php $__currentLoopData = $aidRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aidRecipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($aidRecipient->id); ?>">
                                                    <?php echo e($aidRecipient->name); ?>-<?php echo e($aidRecipient->nik); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ["aid_recipient_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6 mb-3">
                                            <label for="<?php echo e($criteria->code); ?>"
                                                class="form-label"><?php echo e($criteria->name); ?><span
                                                    class="text-danger">*</span></label>
                                            <select class="form-select <?php $__errorArgs = [$criteria->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="<?php echo e($criteria->code); ?>" name="<?php echo e($criteria->code); ?>" required>
                                                <option value="">Pilih <?php echo e($criteria->name); ?></option>
                                                <?php $__currentLoopData = $criteria->sub_criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subCriteria->name); ?>">
                                                        <?php echo e($subCriteria->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = [$criteria->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <a href="<?php echo e(route("aid-recipients-criteria.index")); ?>" class="btn btn-warning">Kembali</a>
                                <button type="submit" class="btn btn-success">Tambah</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/aid_recipients_criteria/create.blade.php ENDPATH**/ ?>