<?php $__env->startSection("title", "Data Survey"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Daftar Survey</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Survey Petugas 1</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <?php
                                
                                // Buat array untuk menyimpan nilai perbandingan
                                $comparisonValues = [];
                                
                                // Buat array untuk menyimpan indeks kriteria
                                $criteriaIndices = [];
                                
                                $criterias->each(function ($c1, $index) use ($criterias, &$comparisonValues, &$criteriaIndices) {
                                    $row = [];
                                    $criterias->each(function ($c2) use ($c1, &$row) {
                                        if ($c1->id === $c2->id) {
                                            // Jika kriteria sama, berikan nilai 1
                                            $row[] = 1;
                                        } else {
                                            // Ambil nilai perbandingan dari matriks perbandingan atau beri nilai default 1 jika belum ada
                                            $comparison = $c1
                                                ->pairwise_matrices()
                                                ->where("compared_criteria_id", $c2->id)
                                                ->where("user_id", 2)
                                                ->first();
                                            $value = $comparison ? $comparison->value : 0;
                                            $row[] = $value;
                                        }
                                    });
                                
                                    $comparisonValues[] = $row;
                                    $criteriaIndices[$c1->id] = $index; // Simpan indeks kriteria berdasarkan ID
                                });
                                
                                // Output tabel
                                echo "<table class='table table-striped'>";
                                
                                // Header baris pertama (nama kriteria)
                                echo "<tr><td></td>";
                                $criterias->each(function ($c) {
                                    echo "<td><b>{$c->name}</b></td>";
                                });
                                echo "</tr>";
                                
                                foreach ($criterias as $c1) {
                                    echo "<tr><td><b>{$c1->name}</b></td>";
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices[$c1->id];
                                        $index2 = $criteriaIndices[$c2->id];
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", 2)
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                        echo "<td>{$comparisonValues[$index1][$index2]}</td>";
                                    }
                                    echo "</tr>";
                                }
                                
                                echo "</table>";
                                
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h4>Data Survey Petugas 2</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <?php
                                
                                // Buat array untuk menyimpan nilai perbandingan
                                $comparisonValues2 = [];
                                
                                // Buat array untuk menyimpan indeks kriteria
                                $criteriaIndices2 = [];
                                
                                $criterias->each(function ($c1, $index) use ($criterias, &$comparisonValues2, &$criteriaIndices2) {
                                    $row2 = [];
                                
                                    $criterias->each(function ($c2) use ($c1, &$row2) {
                                        if ($c1->id === $c2->id) {
                                            // Jika kriteria sama, berikan nilai 1
                                            $row2[] = 1;
                                        } else {
                                            // Ambil nilai perbandingan dari matriks perbandingan atau beri nilai default 1 jika belum ada
                                            $comparison2 = $c1
                                                ->pairwise_matrices()
                                                ->where("compared_criteria_id", $c2->id)
                                                ->where("user_id", 3) // Ganti user_id dengan ID petugas yang bersangkutan
                                                ->first();
                                            $value2 = $comparison2 ? $comparison2->value : 0;
                                            $row2[] = $value2;
                                        }
                                    });
                                
                                    $comparisonValues2[] = $row2;
                                    $criteriaIndices2[$c1->id] = $index; // Simpan indeks kriteria berdasarkan ID
                                });
                                
                                // Output tabel
                                echo "<table class='table table-striped'>";
                                
                                // Header baris pertama (nama kriteria)
                                echo "<tr><td></td>";
                                $criterias->each(function ($c) {
                                    echo "<td><b>{$c->name}</b></td>";
                                });
                                echo "</tr>";
                                
                                foreach ($criterias as $c1) {
                                    echo "<tr><td><b>{$c1->name}</b></td>";
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices2[$c1->id];
                                        $index2 = $criteriaIndices2[$c2->id];
                                        $pairwise_matrices2 = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", 3) // Ganti user_id dengan ID petugas yang bersangkutan
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices2_id = $pairwise_matrices2 ? $pairwise_matrices2->id : null; // Mengambil ID pairwise_matrices jika ada
                                        echo "<td>{$comparisonValues2[$index1][$index2]}</td>";
                                    }
                                    echo "</tr>";
                                }
                                
                                echo "</table>";
                                
                                ?>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pairwise_matrices/index.blade.php ENDPATH**/ ?>