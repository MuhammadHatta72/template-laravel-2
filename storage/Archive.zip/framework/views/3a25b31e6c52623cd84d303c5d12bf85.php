<?php $__env->startSection("title", "Detail Penerima Bantuan"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Penerima Bantuan</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Penerima Bantuan</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-1">
                                    <label for="name" class="form-label"><b>Nama Sub Kriteria</b></label>
                                    <p><?php echo e($subCriteria->name); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="criteria" class="form-label"><b>Nama Kriteria</b></label>
                                    <p><?php echo e($subCriteria->criteria->name); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="value" class="form-label"><b>Nilai</b></label>
                                    <p><?php echo e($subCriteria->value); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route("subcriterias.index")); ?>" class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/sub_criterias/show.blade.php ENDPATH**/ ?>