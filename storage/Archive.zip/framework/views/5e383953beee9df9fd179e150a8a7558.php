<?php $__env->startSection("title", "Detail Masyarakat"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Masyarakat</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Masyarakat</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <?php if($aidRecipient->photo): ?>
                                        <img src="<?php echo e(asset("storage/assets/photos/" . $aidRecipient->photo)); ?>"
                                            alt="Foto Masyarakat" style="width: 30%;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset("assets/img/avatar/avatar-1.png")); ?>" alt="Foto Masyarakat"
                                            style="width: 50%;">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="name" class="form-label"><b>Nama</b></label>
                                    <p><?php echo e($aidRecipient->name); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="nik" class="form-label"><b>NIK</b></label>
                                    <p><?php echo e($aidRecipient->nik); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="gender" class="form-label"><b>Jenis Kelamin</b></label>
                                    <p><?php echo e($aidRecipient->gender); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="place_of_birth" class="form-label"><b>TTL</b></label>
                                    <p><?php echo e($aidRecipient->place_of_birth); ?>, <?php echo e($aidRecipient->date_of_birth); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="address" class="form-label"><b>Alamat</b></label>
                                    <p><?php echo e($aidRecipient->address); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route("aid-recipients.index")); ?>" class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/aid_recipients/show.blade.php ENDPATH**/ ?>