<?php $__env->startSection("title", "Detail Penerima Bantuan"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Penerima Bantuan</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Penerima Bantuan</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-1">
                                    <label for="name" class="form-label"><b>Nama</b></label>
                                    <p><?php echo e($aidRecipient->name); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="nik" class="form-label"><b>NIK</b></label>
                                    <p><?php echo e($aidRecipient->nik); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="gender" class="form-label"><b>Jenis Kelamin</b></label>
                                    <p><?php echo e($aidRecipient->gender); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="place_of_birth" class="form-label"><b>TTL</b></label>
                                    <p><?php echo e($aidRecipient->place_of_birth); ?>, <?php echo e($aidRecipient->date_of_birth); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="address" class="form-label"><b>Alamat</b></label>
                                    <p><?php echo e($aidRecipient->address); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="status_residence" class="form-label"><b>Status Tempat Tinggal</b></label>
                                    <p><?php echo e($aidRecipient->status_residence); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="floor_type" class="form-label"><b>Jenis Lantai Bangunan</b></label>
                                    <p><?php echo e($aidRecipient->floor_type); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="wall_type" class="form-label"><b>Jenis Dinding Bangunan</b></label>
                                    <p><?php echo e($aidRecipient->wall_type); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="source_lighting" class="form-label"><b>Sumber Penerangan</b></label>
                                    <p><?php echo e($aidRecipient->source_lighting); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="age" class="form-label"><b>Usia</b></label>
                                    <p><?php echo e($aidRecipient->age); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="martial_status" class="form-label"><b>Status Perkawinan</b></label>
                                    <p><?php echo e($aidRecipient->martial_status); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="monthly_income" class="form-label"><b>Penghasilan Bulanan</b></label>
                                    <p><?php echo e($aidRecipient->monthly_income); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="number_dependents" class="form-label"><b>Jumlah Tanggungan</b></label>
                                    <p><?php echo e($aidRecipient->number_dependents); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="number_livestock" class="form-label"><b>Jumlah Ternak</b></label>
                                    <p><?php echo e($aidRecipient->number_livestock); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="recipients_government" class="form-label"><b>Penerima Bantuan
                                            Pemerintah</b></label>
                                    <p><?php echo e($aidRecipient->recipients_government); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route("aid-recipients.index")); ?>" class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/aid_recipients/show.blade.php ENDPATH**/ ?>