<?php $__env->startSection("title", "Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS)"); ?>


<?php $__env->startSection("content"); ?>

    <section class="section">
        <div class="section-header">
            <h1>Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS)</h1>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session("success")); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Matrik Keputusan (X)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Alternatif</th>
                                            <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("criteria_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteriaId => $groupedMatrices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                if ($groupedMatrices->count() > 0) {
                                                    $criteria = $criterias->where("id", $criteriaId)->first();
                                                }
                                                ?>
                                                <th><?php echo e($criteria->code ?? ""); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $totalTiapKolomVertical = [];
                                        
                                        // Inisialisasi array total untuk setiap kolom
                                        foreach ($criterias as $criteria) {
                                            if (!isset($totalTiapKolomVertical[$criteria->id])) {
                                                $totalTiapKolomVertical[$criteria->id] = 0;
                                            }
                                        }
                                        ?>

                                        <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("aid_recipient_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipientId => $groupedRecipients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            if ($groupedRecipients->count() > 0) {
                                                $recipient = $aidRecipientsCriteria->where("id", $recipientId)->first();
                                            }
                                            ?>
                                            <tr>
                                                <td><?php echo e($recipient->aidRecipient->name); ?></td>
                                                <?php $__currentLoopData = $groupedRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $criteria = $criterias->where("id", $recipient->criteria_id)->first();
                                                    $totalTiapKolomVertical[$recipient->criteria_id] += $recipient->value;
                                                    ?>
                                                    <td><?php echo e($recipient->value ?? ""); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>Total</td>
                                            <?php $__currentLoopData = $totalTiapKolomVertical; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($total); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h4>Data Matrik Ternormalisasi (X)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Alternatif</th>
                                            <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("criteria_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteriaId => $groupedMatrices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                if ($groupedMatrices->count() > 0) {
                                                    $criteria = $criterias->where("id", $criteriaId)->first();
                                                }
                                                ?>
                                                <th><?php echo e($criteria->code ?? ""); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("aid_recipient_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipientId => $groupedRecipients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            if ($groupedRecipients->count() > 0) {
                                                $recipient = $aidRecipientsCriteria->where("id", $recipientId)->first();
                                            }
                                            ?>
                                            <tr>
                                                <td><?php echo e($recipient->aidRecipient->name); ?></td>
                                                <?php $__currentLoopData = $groupedRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $value_normalized = number_format($recipient->value / $totalTiapKolomVertical[$recipient->criteria_id], 6);
                                                    ?>
                                                    <td><?php echo e($value_normalized ?? ""); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <?php
                    
                    // Buat array untuk menyimpan nilai perbandingan
                    $comparisonValues = [];
                    
                    // Buat array untuk menyimpan indeks kriteria
                    $criteriaIndices = [];
                    
                    $criterias->each(function ($c1, $index) use ($criterias, &$comparisonValues, &$criteriaIndices) {
                        $row = [];
                    
                        $criterias->each(function ($c2) use ($c1, &$row) {
                            if ($c1->id === $c2->id) {
                                // Jika kriteria sama, berikan nilai 1
                                $row[] = 1;
                            } else {
                                // Ambil nilai perbandingan dari matriks perbandingan atau beri nilai default 1 jika belum ada
                                $comparison = $c1
                                    ->pairwise_matrices()
                                    ->where("compared_criteria_id", $c2->id)
                                    ->where("user_id", auth()->user()->id)
                                    ->first();
                                $value = $comparison ? $comparison->value : 1;
                                $row[] = $value;
                            }
                        });
                    
                        $comparisonValues[] = $row;
                        $criteriaIndices[$c1->id] = $index; // Simpan indeks kriteria berdasarkan ID
                    });
                    
                    foreach ($criterias as $c1) {
                        foreach ($criterias as $c2) {
                            $index1 = $criteriaIndices[$c1->id];
                            $index2 = $criteriaIndices[$c2->id];
                            $pairwise_matrices = $c1
                                ->pairwise_matrices()
                                ->where("compared_criteria_id", $c2->id)
                                ->where("user_id", auth()->user()->id)
                                ->first(); // Ambil objek pairwise_matrices
                            $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                        }
                    }
                    
                    // Menghitung jumlah setiap kolom
                    $columnSums = array_fill(0, count($comparisonValues[0]), 0);
                    
                    foreach ($comparisonValues as $row) {
                        foreach ($row as $index => $value) {
                            $columnSums[$index] += $value;
                        }
                    }
                    
                    $bottomPriorities = [];
                    $totalPriorities = []; // Inisialisasi array totalPriorities di sini
                    $MatrixPws = [];
                    $MatrixDistributionPws = [];
                    
                    // Hitung bobot prioritas
                    foreach ($criterias as $c1) {
                        foreach ($criterias as $c2) {
                            $index1 = $criteriaIndices[$c1->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                            $index2 = $criteriaIndices[$c2->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                            $pairwise_matrices = $c1
                                ->pairwise_matrices()
                                ->where("compared_criteria_id", $c2->id)
                                ->where("user_id", auth()->user()->id)
                                ->first(); // Ambil objek pairwise_matrices
                            $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                            // Bagi nilai dengan total kolom dan batasi digit desimal
                            $cellValue = $columnSums[$index2] != 0 ? number_format($comparisonValues[$index1][$index2] / $columnSums[$index2], 6) : 0;
                            $bottomPriorities[$c1->id][$c2->id] = $cellValue;
                        }
                    
                        // Kolom untuk Total Prioritas
                        $totalPriority = 0;
                        foreach ($bottomPriorities[$c1->id] as $priority) {
                            $totalPriority += $priority;
                        }
                        $result = number_format($totalPriority / count($criterias), 6);
                        $totalPriorities[$c1->id] = "{$result}-{$c1->id}";
                    }
                    
                    ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>Bobot Preferensi (W)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Jenis</th>
                                            <th>W</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $totalPriorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $pw_id = explode("-", $value);
                                            $pw = $pw_id[0];
                                            $id_criteria_pw = $pw_id[1];
                                            $criteria_pw = $criterias->where("id", $id_criteria_pw)->first();
                                            ?>
                                            <tr>
                                                <td><?php echo e($criteria_pw->code); ?></td>
                                                <td><?php echo e($criteria_pw->type); ?></td>
                                                <td><?php echo e($pw); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h4>Data Matriks Ternormalisasi Terbobot (Y)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Alternatif</th>
                                            <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("criteria_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteriaId => $groupedMatrices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                if ($groupedMatrices->count() > 0) {
                                                    $criteria = $criterias->where("id", $criteriaId)->first();
                                                }
                                                ?>
                                                <th><?php echo e($criteria->code ?? ""); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pairwiseMatriceSubCriterias->groupBy("aid_recipient_id"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipientId => $groupedRecipients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            if ($groupedRecipients->count() > 0) {
                                                $recipient = $aidRecipientsCriteria->where("id", $recipientId)->first();
                                            }
                                            ?>
                                            <tr>
                                                <td><?php echo e($recipient->aidRecipient->name); ?></td>
                                                <?php $__currentLoopData = $groupedRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $valuePW = 0;
                                                    foreach ($totalPriorities as $key => $value) {
                                                        $pw_id = explode("-", $value);
                                                        $pw = $pw_id[0];
                                                        $id_criteria_pw = $pw_id[1];
                                                    
                                                        if ($recipient->criteria_id == $id_criteria_pw) {
                                                            $valuePW = $pw;
                                                            break;
                                                        }
                                                    }
                                                    $value_normalized = number_format($recipient->value / $totalTiapKolomVertical[$recipient->criteria_id], 6);
                                                    $value_matrix_y = number_format($value_normalized * $valuePW, 6);
                                                    ?>
                                                    <td><?php echo e($value_matrix_y ?? ""); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/topsis/index.blade.php ENDPATH**/ ?>