<?php $__env->startSection("title", "Data Sub Kriteria"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Daftar Sub Kriteria</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Sub Kriteria</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-striped" id="tablePaging">
                                    <thead>
                                        <tr class="text-center">
                                            <th class="text-center">Nama Sub Kriteria</th>
                                            <th class="text-center">Nama Kriteria</th>
                                            <th class="text-center">Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $subcriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td><?php echo e($subcriteria->name); ?></td>
                                                <td><?php echo e($subcriteria->criteria->name); ?></td>
                                                <td><?php echo e($subcriteria->value); ?></td>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/survey_officer/sub_criterias/index.blade.php ENDPATH**/ ?>