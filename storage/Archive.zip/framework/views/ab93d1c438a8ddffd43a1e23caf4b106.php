<?php $__env->startSection("title", "Detail Penerima Bantuan"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Penerima Bantuan</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Penerima Bantuan</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <?php if($aidRecipientCriteria->aidRecipient->photo): ?>
                                        <img src="<?php echo e(asset("storage/assets/photos/" . $aidRecipientCriteria->aidRecipient->photo)); ?>"
                                            alt="Foto Penerima Bantuan" style="width: 30%;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset("assets/img/avatar/avatar-1.png")); ?>" alt="Foto Penerima Bantuan"
                                            style="width: 50%;">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="name" class="form-label"><b>Nama</b></label>
                                    <p><?php echo e($aidRecipientCriteria->aidRecipient->name); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="nik" class="form-label"><b>NIK</b></label>
                                    <p><?php echo e($aidRecipientCriteria->aidRecipient->nik); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="gender" class="form-label"><b>Jenis Kelamin</b></label>
                                    <p><?php echo e($aidRecipientCriteria->aidRecipient->gender); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="place_of_birth" class="form-label"><b>TTL</b></label>
                                    <p><?php echo e($aidRecipientCriteria->aidRecipient->place_of_birth); ?>,
                                        <?php echo e($aidRecipientCriteria->aidRecipient->date_of_birth); ?></p>
                                </div>
                                <div class="col-md-6 mb-1">
                                    <label for="address" class="form-label"><b>Alamat</b></label>
                                    <p><?php echo e($aidRecipientCriteria->aidRecipient->address); ?></p>
                                </div>
                                <?php $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $criteria->sub_criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $criteriaAidRecipient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($key == $criteria->code && $subCriteria->name == $criterion): ?>
                                                <div class="col-md-6 mb-1">
                                                    <label for="<?php echo e($criteria->code); ?>"
                                                        class="form-label"><b><?php echo e($criteria->name); ?></b></label>
                                                    <p id="<?php echo e($criteria->code); ?>"><?php echo e($subCriteria->name); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <a href="<?php echo e(route("aid-recipients-criteria.index")); ?>"
                                        class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/aid_recipients_criteria/show.blade.php ENDPATH**/ ?>