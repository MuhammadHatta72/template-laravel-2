<?php $__env->startSection("title", "Data Matrik Perbandingan"); ?>


<?php $__env->startSection("content"); ?>

    <style>
        .table-container {
            overflow-x: auto;
        }

        .table-container table {
            width: 100%;
            /* Atur lebar tabel ke 100% */
        }
    </style>

    <section class="section">
        <div class="section-header">
            <h1>Analytical Hierarchical Process - AHP</h1>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session("success")); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Matrik Perbandingan Berpasangan</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <?php
                                
                                // Buat array untuk menyimpan nilai perbandingan
                                $comparisonValues = [];
                                
                                // Buat array untuk menyimpan indeks kriteria
                                $criteriaIndices = [];
                                
                                $criterias->each(function ($c1, $index) use ($criterias, &$comparisonValues, &$criteriaIndices) {
                                    $row = [];
                                
                                    $criterias->each(function ($c2) use ($c1, &$row) {
                                        if ($c1->id === $c2->id) {
                                            // Jika kriteria sama, berikan nilai 1
                                            $row[] = 1;
                                        } else {
                                            // Ambil nilai perbandingan dari matriks perbandingan atau beri nilai default 1 jika belum ada
                                            $comparison = $c1
                                                ->pairwise_matrices()
                                                ->where("compared_criteria_id", $c2->id)
                                                ->where("user_id", auth()->user()->id)
                                                ->first();
                                            $value = $comparison ? $comparison->value : 1;
                                            $row[] = $value;
                                        }
                                    });
                                
                                    $comparisonValues[] = $row;
                                    $criteriaIndices[$c1->id] = $index; // Simpan indeks kriteria berdasarkan ID
                                });
                                
                                // Output tabel
                                echo "<table class='table table-striped'>";
                                
                                // Header baris pertama (nama kriteria)
                                echo "<tr><td></td>";
                                $criterias->each(function ($c) {
                                    echo "<td><b>{$c->name}</b></td>";
                                });
                                echo "</tr>";
                                
                                foreach ($criterias as $c1) {
                                    echo "<tr><td><b>{$c1->name}</b></td>";
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices[$c1->id];
                                        $index2 = $criteriaIndices[$c2->id];
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", auth()->user()->id)
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                        echo "<td>{$comparisonValues[$index1][$index2]}</td>";
                                    }
                                    echo "</tr>";
                                }
                                
                                // Menghitung jumlah setiap kolom
                                $columnSums = array_fill(0, count($comparisonValues[0]), 0);
                                
                                foreach ($comparisonValues as $row) {
                                    foreach ($row as $index => $value) {
                                        $columnSums[$index] += $value;
                                    }
                                }
                                
                                // Output total di bawah tabel
                                echo "<tr><td><b>Total</b></td>";
                                foreach ($columnSums as $sum) {
                                    echo "<td>{$sum}</td>";
                                }
                                echo "</tr>";
                                
                                echo "</table>";
                                
                                ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Bobot Prioritas</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">

                                <?php
                                echo "<table class='table table-striped' style='width: 100%'>";
                                echo "<tr><td></td>";
                                
                                $bottomPriorities = [];
                                $totalPriorities = []; // Inisialisasi array totalPriorities di sini
                                $MatrixPws = [];
                                $MatrixDistributionPws = [];
                                
                                // Hitung bobot prioritas
                                foreach ($criterias as $c1) {
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices[$c1->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $index2 = $criteriaIndices[$c2->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", auth()->user()->id)
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                        // Bagi nilai dengan total kolom dan batasi digit desimal
                                        $cellValue = $columnSums[$index2] != 0 ? number_format($comparisonValues[$index1][$index2] / $columnSums[$index2], 6) : 0;
                                        $bottomPriorities[$c1->id][$c2->id] = $cellValue;
                                    }
                                
                                    // Kolom untuk Total Prioritas
                                    $totalPriority = 0;
                                    foreach ($bottomPriorities[$c1->id] as $priority) {
                                        $totalPriority += $priority;
                                    }
                                    $totalPriorities[$c1->id] = $totalPriority / count($criterias);
                                }
                                
                                // Hitung matriks x PW
                                foreach ($criterias as $c1) {
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices[$c1->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $index2 = $criteriaIndices[$c2->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", auth()->user()->id)
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                        // Bagi nilai dengan total kolom dan batasi digit desimal
                                        $cellValue = $columnSums[$index2] != 0 ? number_format($comparisonValues[$index1][$index2] / $columnSums[$index2], 6) : 0;
                                        $bottomPriorities[$c1->id][$c2->id] = $cellValue;
                                    }
                                
                                    $matrixPw = 0;
                                
                                    // Lakukan pengulangan untuk setiap kriteria lagi
                                    foreach ($criterias as $c2) {
                                        // Ambil indeks kriteria
                                        $index1 = $criteriaIndices[$c1->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $index2 = $criteriaIndices[$c2->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                
                                        // Ambil objek pairwise_matrices
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", auth()->user()->id)
                                            ->first();
                                
                                        // Ambil ID pairwise_matrices jika ada
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null;
                                
                                        // Lakukan perkalian antara nilai matriks perbandingan dengan nilai PW
                                        $cellValue = isset($totalPriorities[$c2->id]) ? $comparisonValues[$index1][$index2] * $totalPriorities[$c2->id] : 0; // Perbaikan: Tambahkan isset untuk memeriksa ketersediaan kunci sebelum mengakses
                                
                                        // Tambahkan hasil perkalian ke nilai Matriks x PW
                                        $matrixPw += $cellValue;
                                    }
                                
                                    $MatrixPws[$c1->id] = $matrixPw;
                                }
                                
                                //Hitung Matrix / PW
                                foreach ($criterias as $c) {
                                    $MatrixDistributionPw = $MatrixPws[$c->id] / $totalPriorities[$c->id];
                                    $MatrixDistributionPws[$c->id] = $MatrixDistributionPw;
                                }
                                
                                // Display Data
                                // Header nama kriteria
                                $criterias->each(function ($c) {
                                    echo "<td><b>{$c->name}</b></td>";
                                });
                                echo "<td><b>Jumlah</b></td>"; // Kolom untuk Total Prioritas
                                echo "<td><b>PW</b></td>"; // Kolom untuk PW
                                echo "<td><b>Matriks x PW</b></td>";
                                echo "<td><b>Matrix / PW</b></td>";
                                
                                foreach ($criterias as $c1) {
                                    echo "<tr><td><b>{$c1->name}</b></td>";
                                    foreach ($criterias as $c2) {
                                        $index1 = $criteriaIndices[$c1->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $index2 = $criteriaIndices[$c2->id] ?? null; // Perbaikan: Tambahkan ?? null untuk menangani kunci yang mungkin tidak ada
                                        $pairwise_matrices = $c1
                                            ->pairwise_matrices()
                                            ->where("compared_criteria_id", $c2->id)
                                            ->where("user_id", auth()->user()->id)
                                            ->first(); // Ambil objek pairwise_matrices
                                        $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                        // Bagi nilai dengan total kolom dan batasi digit desimal
                                        $cellValue = $columnSums[$index2] != 0 ? number_format($comparisonValues[$index1][$index2] / $columnSums[$index2], 6) : 0;
                                        echo "<td>{$cellValue}</td>";
                                        $bottomPriorities[$c1->id][$c2->id] = $cellValue;
                                    }
                                
                                    // Kolom untuk Total Prioritas
                                    $totalPriority = 0;
                                    foreach ($bottomPriorities[$c1->id] as $priority) {
                                        $totalPriority += $priority;
                                    }
                                    $totalPriorities[$c1->id] = $totalPriority / count($criterias);
                                    echo "<td>" . number_format($totalPriority, 6) . "</td>";
                                
                                    // Kolom untuk PW
                                    echo "<td>" . number_format($totalPriorities[$c1->id], 6) . "</td>";
                                
                                    // Kolom untuk Matriks x PW
                                    echo "<td>" . number_format($MatrixPws[$c1->id], 6) . "</td>";
                                
                                    // Kolom untuk Matrix / PW
                                    echo "<td>" . number_format($MatrixDistributionPws[$c1->id], 6) . "</td>";
                                }
                                
                                // Tambahkan baris untuk menampilkan total PW dan total Matrix / PW
                                echo "<tr><td><b>Total</b></td>";
                                
                                // Hitung total PW dan total Matrix / PW
                                $totalPW = 0;
                                $totalMatrixPW = 0;
                                foreach ($criterias as $c) {
                                    $totalPW += $totalPriorities[$c->id];
                                    $totalMatrixPW += $MatrixDistributionPws[$c->id];
                                }
                                
                                // Tampilkan total PW dan total Matrix / PW dengan otomatis
                                for ($i = 0; $i < count($criterias) + 1; $i++) {
                                    echo "<td></td>";
                                }
                                echo "<td><b>" . number_format($totalPW, 6) . "</b></td>";
                                echo "<td></td>";
                                echo "<td><b>" . number_format($totalMatrixPW, 6) . "</b></td>";
                                
                                echo "</tr>";
                                
                                echo "</table>";
                                ?>
                            </div>

                        </div>
                    </div>


                    
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Konsistensi</h4>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">

                                <?php
                                echo "<table class='table table-striped' style='width: 100%'>";
                                echo "<tr><td><b>Lamda Max</b></td><td><b>Lamda Max n</b></td><td><b>CI</b></td><td><b>CR</b></td></tr>";
                                
                                // echo "<tr><td>" . number_format($totalPW, 6) . "</td><td>" . number_format($totalMatrixPW, 6) . "</td><td></td><td></td></tr>";
                                
                                $lamdaMax = $totalMatrixPW / count($criterias);
                                $lamdaMaxn = $lamdaMax - count($criterias);
                                $ci = $lamdaMaxn / (count($criterias) - 1);
                                $cr = $ci / 1.51;
                                
                                echo "<tr><td>" . number_format($lamdaMax, 6) . "</td><td>" . number_format($lamdaMaxn, 6) . "</td><td>" . number_format($ci, 6) . "</td><td>" . number_format($cr, 6) . "</td></tr>";
                                
                                echo "</table>";
                                ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/ahp/index.blade.php ENDPATH**/ ?>