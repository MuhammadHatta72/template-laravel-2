<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="<?php echo e(route("home")); ?>" class="logo">
            <img src="<?php echo e(asset("assets/img/logo_polinema.png")); ?>" alt="logo" width="50" class="img-fluid">
            <span class="logo-text">BLT-DD Boto</span>
        </a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(route("home")); ?>">
            <img src="<?php echo e(asset("assets/img/logo_polinema.png")); ?>" alt="logo" width="40" class="img-fluid">
        </a>
    </div>
    <ul class="sidebar-menu">

        <?php $__env->startSection("sidebar"); ?>

            <li class="menu-header">Dashboard</li>
            <li class="nav-item <?php echo e(request()->is("home") ? "active" : ""); ?>">
                <a href="<?php echo e(route("home")); ?>" class="nav-link">
                    <i class="fas fa-poll-h"></i><span>Dashboard</span>
                </a>
            </li>

            <?php if(auth()->user()->role == "admin"): ?>
                <li class="menu-header">Data</li>

                <li class="nav-item <?php echo e(request()->is("criterias") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("criterias.index")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Kriteria</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("subcriterias") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("subcriterias.index")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Sub Kriteria</span>
                    </a>
                </li>

                

                <li class="nav-item <?php echo e(request()->is(["aid-recipients-criteria", "aid-recipients"]) ? "active" : ""); ?>">
                    <a href="#" class="nav-link has-dropdown">
                        <i class="fas fa-users"></i><span>Penerima Bantuan</span>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="nav-item <?php echo e(request()->is("aid-recipients") ? "active" : ""); ?>">
                            <a href="<?php echo e(route("aid-recipients.index")); ?>" class="nav-link">
                                <i class="fas fa-users"></i><span>Masyarakat</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is("aid-recipients-criteria") ? "active" : ""); ?>">
                            <a href="<?php echo e(route("aid-recipients-criteria.index")); ?>" class="nav-link">
                                <i class="fas fa-users"></i><span>Penerima Bantuan</span>
                            </a>
                        </li>
                    </ul>
                </li>

                

                <li class="nav-item <?php echo e(request()->is("pairwise-matrices-admin") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("pairwise-matrices-admin")); ?>" class="nav-link">
                        <i class="fas fa-user"></i><span>Survey</span>
                    </a>
                </li>

                <li class="menu-header">Perhitungan</li>

                <li class="nav-item <?php echo e(request()->is("gmm") ? "active" : ""); ?> mb-3">
                    <a href="<?php echo e(route("gmm.index")); ?>" class="nav-link">
                        <i class="fas fa-calculator"></i><span>Generelized Method of Moment (GMM)</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("ahp") ? "active" : ""); ?> mb-5">
                    <a href="<?php echo e(route("ahp.index")); ?>" class="nav-link">
                        <i class="fas fa-calculator"></i><span>Analytical Hierarchy Process (AHP)</span>
                    </a>
                </li>
                <li class="nav-item <?php echo e(request()->is("topsis") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("topsis.index")); ?>" class="nav-link">
                        <i class="fas fa-calculator"></i><span>Technique for Order of Preference by Similarity to Ideal
                            Solution (TOPSIS)</span>
                    </a>
                </li>
            <?php elseif(auth()->user()->role == "survey_officer"): ?>
                <li class="menu-header">Data</li>

                <li class="nav-item <?php echo e(request()->is("criterias-survey-officer") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("criterias-survey-officer")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Kriteria</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("subcriterias-survey-officer") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("subcriterias-survey-officer")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Sub Kriteria</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("aid-recipients-survey-officer") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("aid-recipients-survey-officer")); ?>" class="nav-link">
                        <i class="fas fa-users"></i><span>Penerima Bantuan</span>
                    </a>
                </li>

                <li class="menu-header">Analisis</li>
                <li class="nav-item <?php echo e(request()->is("pairwise-matrices") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("pairwise-matrices.index")); ?>" class="nav-link">
                        <i class="fas fa-search"></i><span>Survey</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="menu-header">Data</li>

                <li class="nav-item <?php echo e(request()->is("criterias-user") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("criterias-user")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Kriteria</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("subcriterias-user") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("subcriterias-user")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Sub Kriteria</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("aid-recipients-user") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("aid-recipients-user")); ?>" class="nav-link">
                        <i class="fas fa-users"></i><span>Penerima Bantuan</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is("pairwise-matrices-user") ? "active" : ""); ?>">
                    <a href="<?php echo e(route("pairwise-matrices-user")); ?>" class="nav-link">
                        <i class="fas fa-bookmark"></i><span>Survey</span>
                    </a>
                </li>
            <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
    </ul>
</aside>
<?php /**PATH /var/www/html/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>