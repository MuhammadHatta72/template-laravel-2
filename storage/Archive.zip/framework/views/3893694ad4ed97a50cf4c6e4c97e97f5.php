<?php $__env->startSection("title", "Detail Kriteria"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Kriteria</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Kriteria</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-1">
                                    <label for="name" class="form-label"><b>Nama</b></label>
                                    <p><?php echo e($criteria->name); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="code" class="form-label"><b>Kode</b></label>
                                    <p><?php echo e($criteria->code); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="type" class="form-label"><b>Jenis Kriteria</b></label>
                                    <p><?php echo e($criteria->type); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route("criterias.index")); ?>" class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/criterias/show.blade.php ENDPATH**/ ?>