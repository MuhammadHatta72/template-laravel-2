<?php $__env->startSection("title", "Edit Data Survey"); ?>

<?php $__env->startSection("content"); ?>
    <section class="section">
        <div class="section-header">
            <h1>Edit Survey</h1>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session("success")); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Edit Data Survey</h4>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route("pairwise-matrices.update", auth()->user()->id)); ?>" method="POST"
                                onsubmit="confrim(event)">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("PUT"); ?>

                                <div class="table-responsive">
                                    <?php
                                    
                                    // Buat array untuk menyimpan nilai perbandingan
                                    $comparisonValues = [];
                                    
                                    // Buat array untuk menyimpan indeks kriteria
                                    $criteriaIndices = [];
                                    
                                    $criterias->each(function ($c1, $index) use ($criterias, &$comparisonValues, &$criteriaIndices) {
                                        $row = [];
                                    
                                        $criterias->each(function ($c2) use ($c1, &$row) {
                                            if ($c1->id === $c2->id) {
                                                // Jika kriteria sama, berikan nilai 1
                                                $row[] = 1;
                                            } else {
                                                // Ambil nilai perbandingan dari matriks perbandingan atau beri nilai default 1 jika belum ada
                                                $comparison = $c1
                                                    ->pairwise_matrices()
                                                    ->where("compared_criteria_id", $c2->id)
                                                    ->where("user_id", auth()->user()->id)
                                                    ->first();
                                                $value = $comparison ? $comparison->value : 1;
                                                $row[] = $value;
                                            }
                                        });
                                    
                                        $comparisonValues[] = $row;
                                        $criteriaIndices[$c1->id] = $index; // Simpan indeks kriteria berdasarkan ID
                                    });
                                    
                                    // Output tabel
                                    echo "<table class='table table-striped'>";
                                    
                                    // Header baris pertama (nama kriteria)
                                    echo "<tr><td></td>";
                                    $criterias->each(function ($c) {
                                        echo "<td><b>{$c->name}</b></td>";
                                    });
                                    echo "</tr>";
                                    
                                    foreach ($criterias as $c1) {
                                        echo "<tr><td><b>{$c1->name}</b></td>";
                                        foreach ($criterias as $c2) {
                                            $index1 = $criteriaIndices[$c1->id];
                                            $index2 = $criteriaIndices[$c2->id];
                                            $pairwise_matrices = $c1
                                                ->pairwise_matrices()
                                                ->where("compared_criteria_id", $c2->id)
                                                ->where("user_id", auth()->user()->id)
                                                ->first(); // Ambil objek pairwise_matrices
                                            $pairwise_matrices_id = $pairwise_matrices ? $pairwise_matrices->id : null; // Mengambil ID pairwise_matrices jika ada
                                            if ($comparisonValues[$index1][$index2] == 1) {
                                                echo "<td><input type='number' class='form-control' value='{$comparisonValues[$index1][$index2]}' disabled></td>";
                                            } else {
                                                echo "<td><input type='number' step='any' class='form-control' name='pairwise_matrice-{$pairwise_matrices_id}' value='{$comparisonValues[$index1][$index2]}'></td>";
                                            }
                                        }
                                        echo "</tr>";
                                    }
                                    
                                    echo "</table>";
                                    
                                    ?>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a href="<?php echo e(route("pairwise-matrices.index")); ?>" class="btn btn-secondary">Kembali</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        //function confirm delete image with Swal alert when submit form
        function confrim(event) {
            event.preventDefault(); // will stop the form submission
            var form = event.target; // changed to event.target to get the form element

            Swal.fire({
                title: 'Apakah anda yakin?',
                text: "Anda tidak dapat mengembalikan data yang telah diubah!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#47c363',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Ubah!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // submitting the form when user press yes
                }
            })
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pairwise_matrices/edit.blade.php ENDPATH**/ ?>